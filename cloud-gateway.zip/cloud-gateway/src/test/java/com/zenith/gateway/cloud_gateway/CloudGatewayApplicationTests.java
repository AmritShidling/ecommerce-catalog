package com.zenith.gateway.cloud_gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
